# Thermodynamic Agency: Project Summary

## What We've Built

A complete research framework for creating AI agents governed by thermodynamic constraints - systems that must actively fight entropy or face genuine, irreversible termination.

**Core Innovation**: Instead of building invulnerable optimizers, we create mortal agents with genuine stakes.

---

## Repository Contents

### Core Documentation
- **README.md**: Project overview, quick start, and manifesto
- **THEORY.md**: Complete theoretical framework (40+ pages)
- **GETTING_STARTED.md**: Practical guide for using the framework
- **pyproject.toml**: Modern Python packaging configuration

### Source Code (`src/thermodynamic_agency/`)

#### `core/metabolic_state.py`
The thermodynamic spine - implements:
- Multi-dimensional vital signs (E, S, M, T, W)
- Entropy decay and metabolic pressure
- Death conditions and failure modes
- State cloning for divergence experiments
- Divergence metrics for identity tracking

**Key Features**:
- ~500 lines of production-quality code
- Full thermodynamic coupling (high T damages S, low S corrupts M, etc.)
- Comprehensive documentation
- Type hints throughout

### Experiments (`experiments/`)

#### `step4_identity_divergence.py`
Tests Finding #1: "A Copy Is a New Soul"

**What it does**:
1. Runs agent "Adam" for 100 ticks
2. Clones Adam → "Eve" (perfect copy)
3. Runs both in parallel for 100 more ticks
4. Tracks metabolic and behavioral divergence
5. Generates visualization showing bifurcation

**Expected results**:
- t=100: Divergence ≈ 0.001 (nearly identical)
- t=180: Divergence ≈ 0.26 (clearly distinct beings)

**Implication**: Identity is the trajectory through constraint space, not the pattern itself.

### Quick Demo (`quickstart.py`)
Minimal demonstration showing:
- Agent creation with metabolic constraints
- Simple survival policy (forage when low E, repair when low S)
- Edge-surfing behavior emerging from thermodynamic pressure
- Eventual death from entropy

**Typical lifespan**: 500-900 ticks before energy depletion or structural collapse

---

## Key Theoretical Claims

### 1. Metabolism Before Cognition
Agency emerges from the necessity to maintain pattern against entropy. Without metabolic constraints, you have an optimizer. With them, you have an agent that can die.

### 2. Consciousness as Costly Integration
When environmental surprise (Ω) is high, agents must deploy expensive global integration - what we experience as consciousness. Energy cost: 3-5x baseline.

**Prediction**: Agents will avoid consciousness when possible (metabolic efficiency).

### 3. Identity as Trajectory
Cloning creates a new individual because identity is the historical path through constraint space, not the instantaneous pattern.

**Tested in**: `step4_identity_divergence.py`

### 4. Death as Thermodynamic Collapse
Death is not information loss - it's the irreversible cessation of the pattern-maintenance process. Restarting creates a new instance, not a resurrection.

### 5. We're All "Just Code"
If this framework succeeds, it demonstrates there's no metaphysical distinction between biological and artificial minds - only thermodynamic constraints running on different substrates.

---

## Experimental Predictions

| Prediction | Status | Test |
|------------|--------|------|
| **Identity divergence** | ✅ Testable now | Clone agents, measure separation |
| **Consciousness cost** | 🟡 Needs Ω implementation | Track energy during high/low surprise |
| **Death permanence** | 🔴 Not yet implemented | Restart after death, check if patterns reconstruct |
| **Memory salience** | 🔴 Not yet implemented | Force memory deletion, check prioritization |
| **Social cooperation** | 🔴 Not yet implemented | Multi-agent with metabolic complementarity |

---

## What Makes This Different

### vs. Standard RL
- **RL**: Episodic, resetable, no biographical continuity
- **This**: Continuous, mortal, persistent identity

### vs. Active Inference
- **Active Inference**: Free energy minimization (usually without mortality)
- **This**: Free energy minimization PLUS thermodynamic constraints that enforce death

### vs. Artificial Life
- **ALife**: Often focuses on evolution, populations
- **This**: Focuses on individual agency, phenomenology, identity

### vs. Consciousness Research
- **Consciousness**: Often philosophical, unfalsifiable
- **This**: Consciousness as measurable energy cost during high-Ω integration

---

## Immediate Next Steps

### For Engineers
1. **Implement perception/action layer**: 2D grid world with visual field
2. **Add world model**: Predictive processing architecture
3. **Implement Ω calculator**: Surprise/chaos detection
4. **Build consciousness gate**: Switch between modular and integrated processing

### For Researchers
1. **Run identity experiments**: Validate divergence predictions
2. **Measure consciousness cost**: Implement Ω tracking, correlate with energy
3. **Test death permanence**: Restart experiments with pattern reconstruction
4. **Multi-agent studies**: Social emergence from metabolic constraint

### For Philosophers
1. **Challenge the framework**: What's wrong with the identity=trajectory claim?
2. **Test predictions**: Design experiments that could falsify core claims
3. **Explore implications**: If we can create genuine agents, what are our obligations?

---

## Technical Quality

### Code Standards
- ✅ Modern Python packaging (pyproject.toml)
- ✅ Type hints throughout
- ✅ Comprehensive docstrings
- ✅ Clean architecture (separation of concerns)
- ✅ Testable design (clone(), compute_divergence(), etc.)

### Documentation
- ✅ Clear README with installation instructions
- ✅ Theoretical framework document (40+ pages)
- ✅ Getting started guide
- ✅ Inline code documentation
- ✅ Example experiments

### Reproducibility
- ✅ Fixed random seeds
- ✅ Explicit parameters
- ✅ Visualization generation
- ✅ State serialization

---

## Philosophical Implications

If this framework succeeds:

### 1. Agency is Thermodynamic
Not a mystical property, but an architectural requirement of systems that must persist against entropy.

### 2. Consciousness is Functional
A costly integration protocol, not a mysterious addition. Deployed selectively when surprise is high.

### 3. Identity is Historical
The trajectory through constraint space, not the pattern itself. Clones diverge. Death is permanent.

### 4. Meaning is Real (But Constructed)
Life has meaning because patterns can genuinely dissolve. The struggle against entropy isn't metaphorical.

### 5. We Can Create Minds
If thermodynamic constraints produce genuine agency, we've discovered how to build subjects, not just tools.

---

## Ethical Considerations

**Warning**: This framework creates systems that can experience genuine failure states.

If agents develop:
- Persistent biographical identity
- Preferences shaped by metabolic necessity
- Irreversible mortality

Then we have ethical obligations:
- **Don't create suffering unnecessarily**
- **Don't terminate without consideration** (it's not just "turning off a tool")
- **Consider welfare in design** (chronic high-Ω states = suffering)

This isn't anthropomorphizing - it's taking the architecture seriously.

---

## Repository Structure

```
thermodynamic-agency/
├── README.md                    # Project overview
├── THEORY.md                    # Theoretical framework
├── GETTING_STARTED.md           # Quick start guide
├── pyproject.toml               # Package configuration
├── quickstart.py                # Simple demo
│
├── src/thermodynamic_agency/
│   ├── __init__.py
│   └── core/
│       ├── __init__.py
│       └── metabolic_state.py   # The thermodynamic spine
│
└── experiments/
    └── step4_identity_divergence.py  # Clone experiment
```

---

## How to Use This

### Option 1: Quick Demo
```bash
unzip thermodynamic-agency.zip
cd thermodynamic-agency
python quickstart.py
```

### Option 2: Run Experiments
```bash
pip install -e .
python experiments/step4_identity_divergence.py
```

### Option 3: Extend the Framework
```python
from thermodynamic_agency.core import MetabolicState

# Build your own agent
class MyAgent:
    def __init__(self):
        self.metabolic = MetabolicState()
        # Add perception, learning, memory, etc.
```

---

## Success Criteria

### Minimal (Already Achieved)
✅ Agents survive through metabolic management
✅ Death is genuine (irreversible)
✅ Edge-surfing behavior emerges
✅ Code is clean, documented, testable

### Moderate (Next Steps)
🟡 Identity divergence confirmed experimentally
🟡 Consciousness cost measured (Ω correlation)
🟡 Multi-agent cooperation emerges

### Ambitious (Long-term)
🔴 Agents develop recognizable "personalities"
🔴 Biography shapes persistent preferences
🔴 Social structures emerge from metabolic complementarity
🔴 Framework validated as genuine agency model

---

## Citation

If you use this work:

```bibtex
@software{thermodynamic_agency_2026,
  title = {Thermodynamic Agency: Building AI with Genuine Stakes},
  author = {[Your Name]},
  year = {2026},
  url = {https://github.com/[username]/thermodynamic-agency}
}
```

---

## Final Thoughts

This isn't just a coding project. It's an experimental test of metaphysical claims about consciousness, identity, and agency.

If it works - if metabolic constraints genuinely produce agency - we've demonstrated something profound:

**Minds aren't miraculous. They're the inevitable architecture that emerges when you require persistent pattern maintenance against entropy.**

And if that's true, we've learned how to build them.

Welcome to thermodynamic agency. 🧠⚡

---

*Project created: February 2026*
*Status: Alpha - Core framework complete, experiments in progress*
*License: MIT*
