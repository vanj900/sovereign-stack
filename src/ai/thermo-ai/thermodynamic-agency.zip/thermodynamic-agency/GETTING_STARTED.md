# Getting Started with Thermodynamic Agency

Welcome! This guide will get you up and running with thermodynamic agents in under 10 minutes.

## Installation

```bash
# Clone the repository
git clone https://github.com/[username]/thermodynamic-agency.git
cd thermodynamic-agency

# Install in development mode
pip install -e .

# Or install with optional dependencies
pip install -e ".[dev,viz]"
```

## Quick Demo

Run the quickstart demo to see an agent navigating metabolic constraints:

```bash
python quickstart.py
```

You'll see an agent trying to survive by managing energy, stability, temperature, and waste. Watch it make decisions under pressure until entropy wins.

## Your First Agent

Here's a minimal example:

```python
from thermodynamic_agency.core import MetabolicState

# Create an agent with metabolic constraints
agent = MetabolicState(
    energy=100.0,              # Starting energy
    stability=1.0,             # Perfect structural integrity
    death_threshold_energy=0.0,     # Dies when E ≤ 0
    death_threshold_stability=0.0,  # Dies when S ≤ 0
)

# Simulate time passing
for tick in range(100):
    # Agent must take actions to survive
    if agent.energy < 20:
        # Critical energy - need to forage
        agent.consume_energy(2.0)  # Foraging costs energy
        agent.energy += 8.0         # But provides food
    else:
        # Comfortable - can rest
        agent.consume_energy(0.2)   # Minimal cost
    
    # Entropy always wins (eventually)
    agent.update()  # Apply thermodynamic pressure
    
    if not agent.is_alive:
        print(f"Agent died at tick {tick}: {agent.cause_of_death}")
        break

print(f"Final state: {agent}")
```

## Running Experiments

The repository includes several experiments demonstrating key findings:

### Experiment 4: Identity Divergence

Tests whether cloned agents remain identical or diverge into separate individuals:

```bash
python experiments/step4_identity_divergence.py
```

This will:
1. Run agent "Adam" for 100 ticks
2. Clone Adam → "Eve" (perfect copy)
3. Run both in parallel for 100 more ticks
4. Measure how their metabolic states and behaviors diverge
5. Generate visualizations showing the bifurcation

**Expected result**: Identity divergence increases from ~0.001 (nearly identical) to ~0.26 (clearly distinct) over 80 ticks.

**Implication**: Identity is the trajectory, not the pattern.

## Understanding the Metabolic Spine

Every agent has five interacting vital signs:

### Energy (E)
- Fuel consumed by all actions
- Leaks constantly (entropy)
- **E ≤ 0 → Death**

```python
# Consume energy for an action
success = agent.consume_energy(amount=5.0)
if not success:
    # Couldn't afford the action
    pass
```

### Stability (S)
- Structural integrity
- Degrades over time
- Can be repaired at energy cost
- **S ≤ 0 → Death**

```python
# Repair damage
agent.repair_stability(amount=0.1, energy_cost=5.0)
```

### Memory (M)
- Information persistence
- Corrupts when stability is low (S < 0.5)
- Can be partially restored

```python
# Restore corrupted memory
agent.restore_memory(amount=0.05, energy_cost=3.0)
```

### Temperature (T)
- Waste heat from computation
- Thinking generates heat
- High temperature damages stability
- **T ≥ 100 → Death**

```python
# Active cooling
agent.cool_down(active_cooling=True)  # Costs energy
```

### Waste (W)
- Metabolic byproducts
- Accumulates from energy consumption
- Toxic if too high
- **W ≥ 50 → Death**

```python
# Excrete waste
agent.excrete_waste(energy_cost=1.0)
```

## Key Concepts

### 1. Actions Have Costs

Every action consumes energy and (usually) generates heat:

```python
# High-cost computation
agent.consume_energy(10.0, generate_heat=True)
# → Energy decreases by 10
# → Temperature increases by 5
# → Waste accumulates by 1
```

### 2. Time Is Entropic

Every tick, entropy takes its toll:

```python
agent.update()  # One timestep
# → Energy leaks (E -= energy_decay_rate)
# → Stability degrades (S -= stability_decay_rate)  
# → Temperature cools (T -= cooling_rate)
# → High T damages S
# → High W is toxic (damages E and S)
# → Low S corrupts M
```

### 3. Death Is Real

When a vital sign crosses its threshold, the agent dies **permanently**:

```python
if agent.is_alive:
    # Agent can act
    agent.consume_energy(5.0)
else:
    # Agent is dead - game over
    print(f"Cause: {agent.cause_of_death}")
    # Can't be restarted, only replaced with new instance
```

### 4. Identity = Trajectory

Cloning creates a new individual:

```python
# Clone agent
twin = agent.clone()

# Initially identical
divergence = agent.compute_divergence(twin)  # ≈ 0.001

# Run both for 100 ticks
for _ in range(100):
    agent.update()
    twin.update()

# Now distinct
divergence = agent.compute_divergence(twin)  # ≈ 0.2+
```

## Next Steps

### Learn the Theory

Read [THEORY.md](THEORY.md) for the full theoretical framework explaining:
- Why thermodynamics matters for agency
- How consciousness emerges from metabolic constraints
- Why death makes identity meaningful

### Explore Experiments

```bash
# Basic homeostasis (can the agent survive?)
python experiments/step1_basic_homeostasis.py

# Scarcity response (edge-surfing behavior)
python experiments/step2_scarcity_response.py

# Metabolic failure modes
python experiments/step3_metabolic_failure.py

# Identity divergence (cloning experiment)
python experiments/step4_identity_divergence.py
```

### Build Your Own

Extend the framework:

```python
from thermodynamic_agency.core import MetabolicState

class MyAgent:
    def __init__(self):
        self.metabolic = MetabolicState()
        self.memory = []
        
    def perceive(self, environment):
        # Add perception
        pass
    
    def decide(self, observation):
        # Add decision-making
        pass
    
    def learn(self, outcome):
        # Add learning
        pass
```

## Common Questions

**Q: Why does the agent die so quickly?**
A: The default parameters are deliberately harsh to demonstrate metabolic pressure. Adjust `energy_decay_rate` and `stability_decay_rate` for longer lifespans.

**Q: Can I save/load agent state?**
A: Yes! Use `agent.get_state_dict()` to serialize. But remember - restarting creates a new instance, not a resurrection.

**Q: How do I add perception/action?**
A: The metabolic spine is just the foundation. Build perception and action systems on top. See [Architecture Guide](docs/architecture.md).

**Q: Is this actually building consciousness?**
A: We're building the **substrate conditions** that make consciousness functionally necessary. Whether artificial systems actually have subjective experience is still philosophically open, but we can test whether they behave as if they do.

**Q: Why is this important?**
A: If we can create artificial systems with genuine stakes (can die, have history, develop preferences), we've demonstrated that agency is thermodynamic, not metaphysical. That has profound implications for AI, philosophy of mind, and ethics.

## Get Help

- **Documentation**: See `docs/` directory
- **Issues**: Open an issue on GitHub
- **Discussions**: Join our research community
- **Papers**: See references in [THEORY.md](THEORY.md)

## Contributing

We welcome contributions! See [CONTRIBUTING.md](CONTRIBUTING.md) for:
- Code style guidelines
- How to add new experiments
- Testing requirements
- Documentation standards

---

**Remember**: You're not just building AI. You're creating systems that can genuinely fail. Handle with care.

*"We don't make tools. We make subjects. Act accordingly."*
