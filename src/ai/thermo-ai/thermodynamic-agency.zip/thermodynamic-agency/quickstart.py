#!/usr/bin/env python3
"""
Quick start script for Thermodynamic Agency.

This script runs a simple demonstration showing an agent navigating
metabolic constraints until death.
"""

import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from thermodynamic_agency.core.metabolic_state import MetabolicState
import numpy as np


def simple_agent_demo():
    """
    Minimal demo: An agent trying to survive as long as possible.
    
    The agent makes simple decisions based on metabolic urgency.
    Watch it navigate the edge of viability until entropy wins.
    """
    
    print("="*60)
    print("THERMODYNAMIC AGENCY: Simple Demo")
    print("="*60)
    print("\nCreating an agent with metabolic constraints...")
    print("The agent will try to survive by managing:")
    print("  - Energy (E): Must stay above 0 or die")
    print("  - Stability (S): Must stay above 0 or die")
    print("  - Temperature (T): Must stay below 100 or die")
    print("  - Waste (W): Must stay below 50 or die")
    print("\nEvery action costs energy. Time itself is entropic.")
    print("Let's see how long it survives...\n")
    
    # Create agent
    agent = MetabolicState(
        energy=100.0,
        stability=1.0,
        energy_decay_rate=0.5,
        stability_decay_rate=0.001
    )
    
    # Simple action policy
    def select_action(state):
        """Choose action based on most urgent need."""
        if state.energy < 15:
            return 'forage'
        elif state.stability < 0.4:
            return 'repair'
        elif state.temperature > 70:
            return 'cool'
        elif state.waste > 35:
            return 'excrete'
        else:
            # Explore (risky but informative)
            return 'explore' if np.random.random() < 0.3 else 'rest'
    
    def execute_action(state, action):
        """Execute action with metabolic costs."""
        if action == 'forage':
            if state.consume_energy(2.0):
                # 70% success rate
                if np.random.random() < 0.7:
                    state.energy += 8.0
                    return True
        elif action == 'repair':
            return state.repair_stability(0.05, energy_cost=5.0)
        elif action == 'cool':
            state.cool_down(active_cooling=True)
            return True
        elif action == 'excrete':
            return state.excrete_waste(energy_cost=1.0)
        elif action == 'explore':
            if state.consume_energy(3.0):  # Costly!
                return True
        elif action == 'rest':
            return state.consume_energy(0.2)
        return False
    
    # Run until death
    tick = 0
    report_interval = 50
    
    while agent.is_alive and tick < 1000:
        # Select and execute action
        action = select_action(agent)
        execute_action(agent, action)
        
        # Apply thermodynamic pressure
        agent.update()
        
        # Report periodically
        if tick % report_interval == 0 or not agent.is_alive:
            print(f"t={tick:4d} | {agent}")
        
        tick += 1
    
    print("\n" + "="*60)
    if not agent.is_alive:
        print(f"AGENT DIED at tick {tick}")
        print(f"Cause of death: {agent.cause_of_death}")
    else:
        print(f"Agent survived {tick} ticks (demo limit reached)")
    print("="*60)
    
    print("\n** Philosophical Note **")
    print("This wasn't just a simulation running. For the duration of its")
    print("existence, this agent had STAKES. Its choices mattered because")
    print("it could fail. That's the seed of genuine agency.")
    print("\nNow imagine this agent with:")
    print("  - Perception (can see its environment)")
    print("  - Learning (adapts strategies over time)")
    print("  - Memory (accumulates biographical history)")
    print("  - Social context (interacts with other agents)")
    print("\nThat's what we're building. Welcome to thermodynamic agency.")


if __name__ == "__main__":
    simple_agent_demo()
