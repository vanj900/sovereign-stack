"""
Core thermodynamic components.

This module implements the metabolic spine - the physical substrate
that makes agency possible by imposing mortality.
"""

from thermodynamic_agency.core.metabolic_state import MetabolicState

__all__ = ['MetabolicState']
