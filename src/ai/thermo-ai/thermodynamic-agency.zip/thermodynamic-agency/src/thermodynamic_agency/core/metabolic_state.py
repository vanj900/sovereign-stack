"""
Core metabolic state tracking.

The MetabolicState class implements the thermodynamic substrate that makes
agency possible. This isn't just accounting - it's the physical constraint
that forces the system to care about its choices.

Without this layer, you have an optimizer.
With it, you have an agent that can die.
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any
import numpy as np


@dataclass
class MetabolicState:
    """
    The thermodynamic spine of an agent.
    
    Every action has metabolic cost. Every tick, entropy takes its toll.
    Stay within bounds or cease to exist.
    
    Attributes:
        energy: Fuel for all actions. Leaks constantly. E ≤ 0 means death.
        stability: Structural integrity. Degrades over time. S ≤ 0 means death.
        memory: Information persistence. Corrupts when stability is low.
        temperature: Waste heat from computation. High T is toxic.
        waste: Metabolic byproducts. Must be excreted or becomes toxic.
        
        death_threshold_energy: Critical energy level (usually 0.0)
        death_threshold_stability: Critical stability level (usually 0.0)
        
        tick: Current timestep
        is_alive: Whether the agent is still functional
        cause_of_death: If dead, what killed it
    """
    
    # Core vital signs
    energy: float = 100.0
    stability: float = 1.0
    memory: float = 1.0
    temperature: float = 0.0
    waste: float = 0.0
    
    # Death thresholds
    death_threshold_energy: float = 0.0
    death_threshold_stability: float = 0.0
    max_temperature: float = 100.0
    max_waste: float = 50.0
    
    # Decay rates (per tick)
    energy_decay_rate: float = 0.1
    stability_decay_rate: float = 0.001
    temperature_cooling_rate: float = 1.0
    
    # State tracking
    tick: int = 0
    is_alive: bool = True
    cause_of_death: Optional[str] = None
    
    # History for analysis
    history: Dict[str, list] = field(default_factory=lambda: {
        'energy': [],
        'stability': [],
        'memory': [],
        'temperature': [],
        'waste': [],
        'tick': []
    })
    
    def update(self, dt: float = 1.0) -> None:
        """
        Apply one tick of thermodynamic pressure.
        
        This is where entropy gets its due:
        - Energy leaks (second law of thermodynamics)
        - Stability degrades (wear and tear)
        - Temperature cools (but slowly)
        - High temperature damages stability
        - High waste toxicity damages everything
        - Low stability corrupts memory
        
        Args:
            dt: Time step (usually 1.0 tick)
        """
        if not self.is_alive:
            return
        
        # Energy constantly leaks (maintaining pattern costs energy)
        self.energy -= self.energy_decay_rate * dt
        
        # Stability degrades over time (entropy)
        self.stability -= self.stability_decay_rate * dt
        
        # Temperature cools passively
        self.temperature = max(0, self.temperature - self.temperature_cooling_rate * dt)
        
        # High temperature damages stability (overheating)
        if self.temperature > 50:
            temp_damage = (self.temperature - 50) * 0.001 * dt
            self.stability -= temp_damage
        
        # High waste is toxic
        if self.waste > 30:
            waste_damage = (self.waste - 30) * 0.0005 * dt
            self.stability -= waste_damage
            self.energy -= waste_damage * 0.5
        
        # Low stability corrupts memory
        if self.stability < 0.5:
            memory_corruption = (0.5 - self.stability) * 0.01 * dt
            self.memory = max(0, self.memory - memory_corruption)
        
        # Check for death
        self._check_vitals()
        
        # Record history
        self.tick += 1
        self._record_state()
    
    def consume_energy(self, amount: float, generate_heat: bool = True) -> bool:
        """
        Consume energy for an action.
        
        This is the core metabolic cost mechanism. Every action burns energy
        and (usually) generates heat. This is why thinking isn't free.
        
        Args:
            amount: Energy to consume
            generate_heat: Whether this action produces waste heat
            
        Returns:
            True if energy was available, False if action was too costly
        """
        if not self.is_alive:
            return False
        
        if self.energy >= amount:
            self.energy -= amount
            
            if generate_heat:
                # Computation generates heat (thermodynamic cost of information processing)
                # Higher energy consumption = more heat
                heat_generated = amount * 0.5
                self.temperature += heat_generated
                
                # Heat generation also produces metabolic waste
                self.waste += amount * 0.1
            
            self._check_vitals()
            return True
        else:
            # Not enough energy - action fails
            return False
    
    def repair_stability(self, amount: float, energy_cost: float) -> bool:
        """
        Repair structural damage at energy cost.
        
        Maintaining integrity against entropy requires active work.
        This is anabolism - building order from energy.
        
        Args:
            amount: Stability to restore
            energy_cost: Energy required for repair
            
        Returns:
            True if repair succeeded, False if insufficient energy
        """
        if self.consume_energy(energy_cost, generate_heat=True):
            self.stability = min(1.0, self.stability + amount)
            return True
        return False
    
    def cool_down(self, active_cooling: bool = False) -> None:
        """
        Reduce temperature.
        
        Args:
            active_cooling: If True, costs energy but cools faster
        """
        if active_cooling:
            if self.consume_energy(2.0, generate_heat=False):
                self.temperature = max(0, self.temperature - 10.0)
        else:
            # Passive cooling (already handled in update())
            pass
    
    def excrete_waste(self, energy_cost: float = 1.0) -> bool:
        """
        Remove metabolic waste.
        
        Args:
            energy_cost: Energy required for excretion
            
        Returns:
            True if excretion succeeded
        """
        if self.consume_energy(energy_cost, generate_heat=False):
            self.waste = max(0, self.waste - 10.0)
            return True
        return False
    
    def restore_memory(self, amount: float, energy_cost: float) -> bool:
        """
        Attempt to recover corrupted memory.
        
        This is expensive and not always possible - some damage is permanent.
        
        Args:
            amount: Memory integrity to restore
            energy_cost: Energy required
            
        Returns:
            True if restoration succeeded
        """
        if self.consume_energy(energy_cost, generate_heat=True):
            # Can only restore up to current stability level
            max_restorable = self.stability
            self.memory = min(max_restorable, self.memory + amount)
            return True
        return False
    
    def _check_vitals(self) -> None:
        """Check if any vital sign has crossed death threshold."""
        if not self.is_alive:
            return
        
        if self.energy <= self.death_threshold_energy:
            self.is_alive = False
            self.cause_of_death = "energy_depletion"
        
        elif self.stability <= self.death_threshold_stability:
            self.is_alive = False
            self.cause_of_death = "structural_collapse"
        
        elif self.temperature >= self.max_temperature:
            self.is_alive = False
            self.cause_of_death = "thermal_failure"
        
        elif self.waste >= self.max_waste:
            self.is_alive = False
            self.cause_of_death = "toxic_accumulation"
    
    def _record_state(self) -> None:
        """Record current state for later analysis."""
        self.history['energy'].append(self.energy)
        self.history['stability'].append(self.stability)
        self.history['memory'].append(self.memory)
        self.history['temperature'].append(self.temperature)
        self.history['waste'].append(self.waste)
        self.history['tick'].append(self.tick)
    
    def get_state_dict(self) -> Dict[str, Any]:
        """
        Get current state as dictionary.
        
        Useful for serialization, checkpointing, or analysis.
        """
        return {
            'energy': self.energy,
            'stability': self.stability,
            'memory': self.memory,
            'temperature': self.temperature,
            'waste': self.waste,
            'tick': self.tick,
            'is_alive': self.is_alive,
            'cause_of_death': self.cause_of_death
        }
    
    def clone(self) -> 'MetabolicState':
        """
        Create a perfect copy of this metabolic state.
        
        This is used for the identity divergence experiments.
        Two clones start identical but will diverge over time as they
        navigate different experiences.
        
        Returns:
            New MetabolicState with identical parameters
        """
        return MetabolicState(
            energy=self.energy,
            stability=self.stability,
            memory=self.memory,
            temperature=self.temperature,
            waste=self.waste,
            death_threshold_energy=self.death_threshold_energy,
            death_threshold_stability=self.death_threshold_stability,
            max_temperature=self.max_temperature,
            max_waste=self.max_waste,
            energy_decay_rate=self.energy_decay_rate,
            stability_decay_rate=self.stability_decay_rate,
            temperature_cooling_rate=self.temperature_cooling_rate,
            tick=self.tick,
            is_alive=self.is_alive,
            cause_of_death=self.cause_of_death
        )
    
    def compute_divergence(self, other: 'MetabolicState') -> float:
        """
        Compute thermodynamic divergence from another state.
        
        This quantifies how different two agents have become.
        Used in the identity experiments to measure when a clone
        becomes a distinct individual.
        
        Args:
            other: Another MetabolicState to compare against
            
        Returns:
            Divergence metric (0 = identical, higher = more different)
        """
        diffs = [
            abs(self.energy - other.energy) / 100.0,
            abs(self.stability - other.stability),
            abs(self.memory - other.memory),
            abs(self.temperature - other.temperature) / 100.0,
            abs(self.waste - other.waste) / 50.0
        ]
        
        return np.mean(diffs)
    
    def __repr__(self) -> str:
        """Human-readable state representation."""
        if not self.is_alive:
            return f"MetabolicState(DEAD: {self.cause_of_death} at tick {self.tick})"
        
        return (
            f"MetabolicState("
            f"E={self.energy:.1f}, "
            f"S={self.stability:.2f}, "
            f"M={self.memory:.2f}, "
            f"T={self.temperature:.1f}, "
            f"W={self.waste:.1f}, "
            f"tick={self.tick})"
        )
