"""
Thermodynamic Agency: Building AI with Genuine Stakes

This package implements agents governed by thermodynamic constraints - systems
that must actively maintain their existence against entropy or face genuine
termination.

Core components:
- metabolic_state: The thermodynamic substrate (E, S, M, T, W tracking)
- homeostasis: Vital sign monitoring and survival imperatives
- active_inference: Expected Free Energy minimization
- drives: Multi-objective motivation system
- memory: Biography and persistent identity

The hypothesis: Authentic agency emerges from the crucible of mortality.
"""

__version__ = "0.1.0"
__author__ = "Thermodynamic Agency Research"

from thermodynamic_agency.core.metabolic_state import MetabolicState

__all__ = ['MetabolicState', '__version__']
