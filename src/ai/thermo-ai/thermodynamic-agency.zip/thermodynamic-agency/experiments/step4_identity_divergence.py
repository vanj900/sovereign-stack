"""
Experiment 4: Identity Divergence

This experiment tests Finding #1: "A Copy Is a New Soul"

We clone an agent at t=100 and track how the two instances diverge over time.
Even in identical environments, thermodynamic noise and path-dependent learning
create irreversible bifurcation.

Expected results:
- t=100: Identity divergence ≈ 0.001 (nearly identical)
- t=140: Identity divergence ≈ 0.05-0.10 (starting to differ)  
- t=180: Identity divergence ≈ 0.20-0.30 (clearly separate beings)

The key insight: Identity is not the pattern, it's the *trajectory* through
metabolic constraint space.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import numpy as np
import matplotlib.pyplot as plt
from thermodynamic_agency.core.metabolic_state import MetabolicState


class SimpleAgent:
    """
    Minimal agent with metabolic constraints and stochastic decision-making.
    
    This is deliberately simple to isolate the identity divergence phenomenon.
    All complexity comes from thermodynamic constraint, not sophisticated cognition.
    """
    
    def __init__(self, name: str, metabolic_state: MetabolicState, random_seed: int = None):
        self.name = name
        self.metabolic = metabolic_state
        self.rng = np.random.RandomState(random_seed)
        
        # Simple action repertoire
        self.actions = {
            'rest': {'energy_cost': 0.2, 'stability_gain': 0.0},
            'forage': {'energy_cost': 2.0, 'energy_gain': 5.0},
            'repair': {'energy_cost': 5.0, 'stability_gain': 0.05},
            'cool': {'energy_cost': 2.0, 'temp_reduction': 10.0},
            'excrete': {'energy_cost': 1.0, 'waste_reduction': 10.0}
        }
        
        self.action_history = []
    
    def select_action(self) -> str:
        """
        Select action based on metabolic urgency.
        
        This is a simple heuristic policy, not sophisticated planning.
        The interesting behavior emerges from thermodynamic pressure, not clever code.
        """
        if not self.metabolic.is_alive:
            return 'dead'
        
        # Critical states demand immediate response
        if self.metabolic.energy < 10:
            action = 'forage'
        elif self.metabolic.stability < 0.3:
            action = 'repair'
        elif self.metabolic.temperature > 80:
            action = 'cool'
        elif self.metabolic.waste > 40:
            action = 'excrete'
        else:
            # Non-critical: choose stochastically based on needs
            weights = [
                1.0,  # rest
                max(0, (50 - self.metabolic.energy) / 50),  # forage
                max(0, (1.0 - self.metabolic.stability)),  # repair
                max(0, self.metabolic.temperature / 100),  # cool
                max(0, self.metabolic.waste / 50)  # excrete
            ]
            
            # Add noise - this is where trajectories diverge
            weights = np.array(weights) + self.rng.uniform(0, 0.3, size=len(weights))
            weights = weights / weights.sum()
            
            action = self.rng.choice(list(self.actions.keys()), p=weights)
        
        self.action_history.append(action)
        return action
    
    def execute_action(self, action: str) -> None:
        """Execute the selected action and apply metabolic effects."""
        if not self.metabolic.is_alive or action == 'dead':
            return
        
        action_spec = self.actions[action]
        
        # Consume energy for action
        success = self.metabolic.consume_energy(action_spec['energy_cost'])
        
        if success:
            # Apply action effects
            if action == 'forage':
                # Foraging has stochastic success
                if self.rng.random() < 0.7:  # 70% success rate
                    self.metabolic.energy += action_spec['energy_gain']
            
            elif action == 'repair':
                self.metabolic.stability = min(1.0, 
                    self.metabolic.stability + action_spec['stability_gain'])
            
            elif action == 'cool':
                self.metabolic.temperature = max(0,
                    self.metabolic.temperature - action_spec['temp_reduction'])
            
            elif action == 'excrete':
                self.metabolic.waste = max(0,
                    self.metabolic.waste - action_spec['waste_reduction'])
    
    def step(self) -> None:
        """Run one timestep: select action, execute it, apply entropy."""
        action = self.select_action()
        self.execute_action(action)
        self.metabolic.update()
    
    def clone(self, new_name: str) -> 'SimpleAgent':
        """
        Create a perfect copy with identical metabolic state.
        
        This is the moment of "forking" - two instances with identical state
        but which will diverge as they navigate their own experiences.
        """
        return SimpleAgent(
            name=new_name,
            metabolic_state=self.metabolic.clone(),
            random_seed=self.rng.randint(0, 2**31)  # Different random seed!
        )


def run_divergence_experiment(
    clone_time: int = 100,
    total_time: int = 200,
    random_seed: int = 42
) -> tuple:
    """
    Run the identity divergence experiment.
    
    Args:
        clone_time: When to clone the agent
        total_time: Total simulation time
        random_seed: For reproducibility
    
    Returns:
        (original_agent, cloned_agent, divergence_history)
    """
    print("=== Identity Divergence Experiment ===\n")
    print(f"Running agent 'Adam' until t={clone_time}...")
    
    # Create original agent
    adam = SimpleAgent(
        name="Adam",
        metabolic_state=MetabolicState(
            energy=100.0,
            stability=1.0,
            energy_decay_rate=0.5,
            stability_decay_rate=0.001
        ),
        random_seed=random_seed
    )
    
    # Run until clone time
    for t in range(clone_time):
        adam.step()
        if not adam.metabolic.is_alive:
            print(f"Adam died at t={t}: {adam.metabolic.cause_of_death}")
            return None, None, None
    
    print(f"Adam at t={clone_time}: {adam.metabolic}")
    
    # Clone
    print(f"\nCloning Adam → Eve at t={clone_time}...")
    eve = adam.clone(new_name="Eve")
    print(f"Eve at t={clone_time}: {eve.metabolic}")
    
    # Verify initial identity
    initial_divergence = adam.metabolic.compute_divergence(eve.metabolic)
    print(f"Initial divergence: {initial_divergence:.6f} (should be ≈0.000)")
    
    # Continue running both in parallel
    print(f"\nRunning both agents from t={clone_time} to t={total_time}...")
    
    divergence_history = [(clone_time, initial_divergence)]
    
    for t in range(clone_time, total_time):
        adam.step()
        eve.step()
        
        if t % 20 == 0 or t == total_time - 1:
            div = adam.metabolic.compute_divergence(eve.metabolic)
            divergence_history.append((t, div))
            
            print(f"\nt={t}:")
            print(f"  Adam: {adam.metabolic}")
            print(f"  Eve:  {eve.metabolic}")
            print(f"  Divergence: {div:.4f}")
            
            if not adam.metabolic.is_alive:
                print(f"  Adam died: {adam.metabolic.cause_of_death}")
            if not eve.metabolic.is_alive:
                print(f"  Eve died: {eve.metabolic.cause_of_death}")
    
    return adam, eve, divergence_history


def visualize_results(adam, eve, divergence_history, save_path='results/figures/identity_divergence.png'):
    """Create visualization of the identity divergence experiment."""
    
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    
    fig, axes = plt.subplots(3, 2, figsize=(14, 10))
    fig.suptitle('Identity Divergence: How Clones Become Individuals', fontsize=16, fontweight='bold')
    
    # Extract histories
    adam_history = adam.metabolic.history
    eve_history = eve.metabolic.history
    
    # Plot vital signs
    vital_signs = [
        ('energy', 'Energy (E)', 'tab:orange'),
        ('stability', 'Stability (S)', 'tab:blue'),
        ('temperature', 'Temperature (T)', 'tab:red'),
        ('waste', 'Waste (W)', 'tab:brown')
    ]
    
    for idx, (key, label, color) in enumerate(vital_signs):
        ax = axes[idx // 2, idx % 2]
        ax.plot(adam_history['tick'], adam_history[key], 
                label='Adam', color=color, linewidth=2, alpha=0.7)
        ax.plot(eve_history['tick'], eve_history[key], 
                label='Eve', color=color, linewidth=2, linestyle='--', alpha=0.7)
        ax.set_xlabel('Time (ticks)')
        ax.set_ylabel(label)
        ax.legend()
        ax.grid(True, alpha=0.3)
    
    # Plot divergence over time
    ax = axes[2, 0]
    times, divs = zip(*divergence_history)
    ax.plot(times, divs, color='purple', linewidth=3, marker='o')
    ax.set_xlabel('Time (ticks)')
    ax.set_ylabel('Identity Divergence')
    ax.set_title('Identity Divergence Over Time')
    ax.grid(True, alpha=0.3)
    ax.axhline(y=0.1, color='gray', linestyle='--', alpha=0.5, label='Noticeable difference')
    ax.axhline(y=0.2, color='gray', linestyle=':', alpha=0.5, label='Clearly distinct')
    ax.legend()
    
    # Action distribution comparison
    ax = axes[2, 1]
    adam_actions = np.array(adam.action_history)
    eve_actions = np.array(eve.action_history)
    
    unique_actions = list(adam.actions.keys())
    adam_counts = [np.sum(adam_actions == a) for a in unique_actions]
    eve_counts = [np.sum(eve_actions == a) for a in unique_actions]
    
    x = np.arange(len(unique_actions))
    width = 0.35
    ax.bar(x - width/2, adam_counts, width, label='Adam', alpha=0.7)
    ax.bar(x + width/2, eve_counts, width, label='Eve', alpha=0.7)
    ax.set_xlabel('Action Type')
    ax.set_ylabel('Frequency')
    ax.set_title('Behavioral Divergence')
    ax.set_xticks(x)
    ax.set_xticklabels(unique_actions, rotation=45)
    ax.legend()
    ax.grid(True, alpha=0.3, axis='y')
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"\nVisualization saved to: {save_path}")
    plt.show()


if __name__ == "__main__":
    # Run experiment
    adam, eve, divergence_history = run_divergence_experiment(
        clone_time=100,
        total_time=200,
        random_seed=42
    )
    
    if adam and eve:
        # Analyze results
        print("\n=== Final Analysis ===")
        final_divergence = divergence_history[-1][1]
        
        print(f"\nFinal divergence: {final_divergence:.4f}")
        
        if final_divergence < 0.05:
            print("→ Clones remain nearly identical (unexpected!)")
        elif final_divergence < 0.15:
            print("→ Clones show noticeable differences")
        else:
            print("→ Clones are clearly distinct individuals")
        
        print(f"\nAdam final state: {adam.metabolic}")
        print(f"Eve final state:  {eve.metabolic}")
        
        # Visualize
        visualize_results(adam, eve, divergence_history)
        
        print("\n=== Philosophical Implications ===")
        print("If two agents start identical but diverge through experience,")
        print("then identity is not the pattern - it's the TRAJECTORY.")
        print("\nEach clone is a new soul, forged in its own crucible of choice.")
